// GTA 6 Spoiler Blocker - content script
(() => {
  "use strict";

  // Each term matches at the start of a word, so suffixed forms are caught too
  // (e.g. "GTA's", "GTAV", "GTAVI", "GTA6"). \p{L} covers all Unicode letters.
  const TERMS = [
    // Game title (GTA, GTA 5, GTA V, GTA 6, GTA VI, GTA6, GTAV, GTAVI, Grand Theft Auto)
    "(?<!\\p{L})gta",
    "(?<!\\p{L})grand\\s*theft\\s*auto",
    // Publisher, studio and founders
    "(?<!\\p{L})rockstar",
    "(?<!\\p{L})take[-\\s]?two",
    "(?<!\\p{L})houser",
    // In-game world and characters
    "(?<!\\p{L})liberty\\s*city",
    "(?<!\\p{L})vice\\s*city",
    "(?<!\\p{L})los\\s*santos",
    "(?<!\\p{L})san\\s*andreas",
    "(?<!\\p{L})leonida",
    "(?<!\\p{L})lucia(?!\\p{L})",
    "(?<!\\p{L})jason(?!\\p{L})",
    // Other games by the same studio
    "(?<!\\p{L})red\\s*dead",
    "(?<!\\p{L})max\\s*payne",
    "(?<!\\p{L})la\\s*noire",
    "(?<!\\p{L})midnight\\s*club",
    "(?<!\\p{L})manhunt",
    "(?<!\\p{L})bully(?!\\p{L})",
    // Leaks and spoilers
    "(?<!\\p{L})s[ıi]z(?:ınt|int|dır|dir|dı|di|an)\\p{L}*",
    "(?<!\\p{L})leak\\p{L}*",
    "(?<!\\p{L})spoiler\\p{L}*",
    "(?<!\\p{L})teaser\\p{L}*",
    // Performance / technical discussion
    "(?<![\\p{L}\\d])(?:30|60|120)\\s?fps",
    "(?<!\\p{L})frame\\s?rate",
    // Disappointment and expectations
    "(?<!\\p{L})beklenen\\s+olmad",
    "(?<!\\p{L})beklentiler\\p{L}*\\s+kar[sş][ıiI]lamad",
    "(?<!\\p{L})beklentinin\\s+alt[ıiI]nda",
    "(?<!\\p{L})beklentiyi\\s+kar[sş][ıiI]lamad",
    "(?<!\\p{L})hayal\\s+k[ıiI]r[ıiI]kl[ıiI][ğg]",
    "(?<!\\p{L})y[ıiI]llard[ıiI]r\\s+beklenen",
    "(?<!\\p{L})wait\\s+is\\s+over",
    "(?<!\\p{L})underwhelm\\p{L}*",
    "(?<!\\p{L})disappoint\\p{L}*",
    "(?<!\\p{L})let\\s+down",
    // Long wait phrases (Turkish and English)
    "(?<!\\p{L})13\\s*[- ]?y[ıiIİ]l\\p{L}*\\s+(?:\\p{L}+\\s+){0,2}?bekl",
    "(?<!\\p{L})13[- ]years?\\s+(?:\\p{L}+\\s+){0,2}?(?:wait|anticipat|in the making)",
    // "most anticipated game", "long-awaited game"
    "(?<!\\p{L})(?:most|en\\s+çok)\\s+(?:anticipated|beklenen)\\s+(?:game|oyun)",
    "(?<!\\p{L})long-?awaited\\s+(?:game|oyun)",
  ];

  const BUILTIN = TERMS.join("|");
  let PATTERN = new RegExp(BUILTIN, "iu");

  const escapeRegExp = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  // Add the user's own filter words to the built-in list
  function buildPattern(customTerms) {
    const extra = (customTerms || [])
      .map((t) => String(t).trim())
      .filter(Boolean)
      .map((t) => "(?<!\\p{L})" + escapeRegExp(t).replace(/\s+/g, "\\s*"));
    PATTERN = new RegExp([BUILTIN, ...extra].join("|"), "iu");
  }
  const MARK = "data-spoiler-blocked";
  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "CODE"]);
  // Containers that usually hold one whole item (news card, post, list entry)
  const CARD_SELECTOR = [
    // Generic
    "article", "li", "tr", "[role='article']", "[role='listitem']",
    // YouTube (home, search, sidebar, Shorts, playlists, comments, notifications)
    "ytd-rich-item-renderer", "ytd-video-renderer", "ytd-compact-video-renderer",
    "ytd-grid-video-renderer", "ytd-playlist-renderer", "ytd-compact-playlist-renderer",
    "ytd-radio-renderer", "ytd-compact-radio-renderer", "ytd-reel-item-renderer",
    "ytd-playlist-panel-video-renderer", "ytd-movie-renderer", "ytd-channel-renderer",
    "ytd-comment-thread-renderer", "ytd-notification-renderer", "ytd-post-renderer",
    "ytd-backstage-post-thread-renderer", "yt-lockup-view-model", "ytm-shorts-lockup-view-model",
    "ytm-shorts-lockup-view-model-v2", "ytd-rich-grid-media", "ytd-end-screen-renderer",
    // X / Twitter
    "[data-testid='cellInnerDiv']", "[data-testid='trend']",
    // Facebook
    "[aria-posinset]", "[data-pagelet^='FeedUnit']",
    // Reddit
    "shreddit-post", "shreddit-comment", "faceplate-tracker[noun='post']",
    // Instagram, LinkedIn, TikTok
    "div[data-id^='urn:li:activity']", "[data-e2e='recommend-list-item-container']",
  ].join(", ");
  const MEDIA_SELECTOR = "img, picture, video, figure, [style*='background-image']";
  // How far up the tree to look for a headline's thumbnail
  const MAX_CLIMB = 12;
  const MAX_CARD_TEXT = 600;
  const HEADING_SELECTOR = "h1, h2, h3, h4, h5, h6";

  const textLength = (el) => (el.textContent || "").replace(/\s+/g, " ").trim().length;

  const matches = (s) => typeof s === "string" && s.length > 0 && PATTERN.test(s);
  const HOST = location.hostname.replace(/^www\./, "");

  function safeDecode(s) {
    if (!s) return s;
    try { return decodeURIComponent(s); } catch (e) { return s; }
  }

  // Find the element to hide: a known card container, or the smallest
  // ancestor that also contains the headline's image/video.
  function findContainer(el) {
    let card = el.closest(CARD_SELECTOR);
    if (card && card !== document.body) {
      // Prefer the outermost wrapper of the same item (e.g. YouTube nests several card elements)
      let outer = card.parentElement && card.parentElement.closest(CARD_SELECTOR);
      while (outer && outer !== document.body && textLength(outer) <= textLength(card) + 40) {
        card = outer;
        outer = card.parentElement && card.parentElement.closest(CARD_SELECTOR);
      }
      return card;
    }

    let node = el;
    for (let i = 0; i < MAX_CLIMB; i++) {
      const parent = node.parentElement;
      if (!parent || parent === document.body || parent === document.documentElement) break;
      if (textLength(parent) > MAX_CARD_TEXT) break;
      // A parent with several headlines is a list of items, not a single card
      if (parent.querySelectorAll(HEADING_SELECTOR).length > 1) break;
      node = parent;
      if (node.matches(MEDIA_SELECTOR) || node.querySelector(MEDIA_SELECTOR)) return node;
    }
    return el;
  }

  function hide(el) {
    if (!el || el === document.body || el === document.documentElement) return;
    const target = findContainer(el);
    if (target === document.body || target === document.documentElement) return;
    if (target.hasAttribute(MARK)) return;
    // Remember the original inline display value so it can be restored
    target.setAttribute(MARK, target.style.getPropertyValue("display") || "");
    target.style.setProperty("display", "none", "important");
    // Count each item only once, even if settings change and it is hidden again
    if (!everBlocked.has(target)) {
      everBlocked.add(target);
      newlyBlocked++;
    }
    scheduleReport();
  }

  function checkAttributes(el) {
    if (
      matches(el.getAttribute("alt")) ||
      matches(el.getAttribute("title")) ||
      matches(el.getAttribute("aria-label")) ||
      (el.tagName === "A" && matches(safeDecode(el.getAttribute("href")))) ||
      (el.tagName === "IMG" &&
        (matches(safeDecode(el.getAttribute("src"))) || matches(safeDecode(el.getAttribute("srcset")))))
    ) {
      hide(el);
    }
  }

  function scan(root) {
    if (!root || root.nodeType !== Node.ELEMENT_NODE || SKIP_TAGS.has(root.tagName)) return;

    checkAttributes(root);
    root.querySelectorAll("img, a, [title], [aria-label]").forEach(checkAttributes);

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent || SKIP_TAGS.has(parent.tagName)) return NodeFilter.FILTER_REJECT;
        return matches(node.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      },
    });

    const hits = [];
    while (walker.nextNode()) hits.push(walker.currentNode);
    hits.forEach((node) => hide(node.parentElement));
  }

  // Handle content loaded later (infinite scroll, single-page apps)
  const queue = new Set();
  let scheduled = false;

  // True if an element's text or attributes still contain a blocked term
  function stillMatches(el) {
    if (matches(el.textContent)) return true;
    const attrs = el.querySelectorAll("img, a, [title], [aria-label]");
    for (const a of [el, ...attrs]) {
      if (
        matches(a.getAttribute("alt")) || matches(a.getAttribute("title")) ||
        matches(a.getAttribute("aria-label")) || matches(safeDecode(a.getAttribute("href"))) ||
        (a.tagName === "IMG" && matches(safeDecode(a.getAttribute("src"))))
      ) return true;
    }
    return false;
  }

  function unhide(el) {
    const original = el.getAttribute(MARK);
    el.style.removeProperty("display");
    if (original) el.style.setProperty("display", original);
    el.removeAttribute(MARK);
  }

  // Rows/shelves that become empty once all their items are hidden (e.g. YouTube "Shorts" rows)
  const SHELF_SELECTOR = [
    "ytd-reel-shelf-renderer", "ytd-shelf-renderer", "ytd-rich-shelf-renderer",
    "ytd-rich-section-renderer", "ytd-horizontal-card-list-renderer", "grid-shelf-view-model",
    "ytd-vertical-list-renderer", "yt-horizontal-list-renderer",
  ].join(", ");
  const SHELF_MARK = "data-spoiler-shelf";

  function tidyShelves() {
    document.querySelectorAll(SHELF_SELECTOR).forEach((shelf) => {
      const items = shelf.querySelectorAll(CARD_SELECTOR);
      if (!items.length) return;
      const allHidden = [...items].every((it) => it.closest(`[${MARK}]`));
      if (allHidden && !shelf.hasAttribute(SHELF_MARK)) {
        shelf.setAttribute(SHELF_MARK, shelf.style.getPropertyValue("display") || "");
        shelf.style.setProperty("display", "none", "important");
      } else if (!allHidden && shelf.hasAttribute(SHELF_MARK)) {
        unhideShelf(shelf);
      }
    });
  }

  function unhideShelf(shelf) {
    const original = shelf.getAttribute(SHELF_MARK);
    shelf.style.removeProperty("display");
    if (original) shelf.style.setProperty("display", original);
    shelf.removeAttribute(SHELF_MARK);
  }

  function flush() {
    scheduled = false;
    for (const el of queue) {
      if (!el.isConnected) continue;
      // Some sites (e.g. YouTube) reuse a card for a different video: unhide it if it no longer matches
      const hiddenCard = el.closest(`[${MARK}]`);
      if (hiddenCard && !stillMatches(hiddenCard)) unhide(hiddenCard);
      scan(el);
    }
    queue.clear();
    tidyShelves();
    scheduleReport();
  }

  function enqueue(node) {
    const el = node && node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    if (el && el.nodeType === Node.ELEMENT_NODE) queue.add(el);
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(flush);
    }
  }

  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.type === "childList") {
        m.addedNodes.forEach(enqueue);
        if (m.removedNodes.length) enqueue(m.target);
      } else if (m.type === "characterData" && m.target.parentElement) {
        enqueue(m.target.parentElement);
      } else if (m.type === "attributes") {
        enqueue(m.target);
      }
    }
  });

  let enabled = false;
  let newlyBlocked = 0;
  const everBlocked = new WeakSet();
  let reportTimer = null;

  const blockedCount = () => document.querySelectorAll(`[${MARK}]`).length;

  // Tell the background worker how many items are hidden (for the badge and total)
  function report() {
    reportTimer = null;
    const added = newlyBlocked;
    newlyBlocked = 0;
    try {
      chrome.runtime.sendMessage({ type: "count", count: blockedCount(), added, active: enabled });
    } catch (e) {
      // Extension was reloaded; this page's script is orphaned
    }
  }

  function scheduleReport() {
    if (!reportTimer) reportTimer = setTimeout(report, 300);
  }

  function enable() {
    if (enabled || !document.body) return;
    enabled = true;
    scan(document.body);
    tidyShelves();
    observer.observe(document.body, {
      childList: true, subtree: true, characterData: true,
      attributes: true, attributeFilter: ["title", "aria-label", "alt", "href", "src"],
    });
    scheduleReport();
  }

  function disable() {
    if (!enabled) return;
    enabled = false;
    observer.disconnect();
    queue.clear();
    document.querySelectorAll(`[${MARK}]`).forEach(unhide);
    document.querySelectorAll(`[${SHELF_MARK}]`).forEach(unhideShelf);
    newlyBlocked = 0;
    scheduleReport();
  }

  function isAllowedSite(allowedSites) {
    return (allowedSites || []).some((site) => HOST === site || HOST.endsWith("." + site));
  }

  const DEFAULTS = { enabled: true, allowedSites: [], customTerms: [] };

  // Re-read settings and re-apply from scratch (handles removed filters too)
  // Never run on this extension's own pages (repo, store listing), or they would be emptied
  const SELF_PAGE = /gta6spoilerblocker|spoiler[\s_-]?blocker/i;
  const isOwnPage = () => SELF_PAGE.test(location.href) || SELF_PAGE.test(document.title);

  function applySettings() {
    chrome.storage.local.get(DEFAULTS, (data) => {
      if (isOwnPage()) {
        disable();
        return;
      }
      buildPattern(data.customTerms);
      disable();
      if (data.enabled && !isAllowedSite(data.allowedSites)) enable();
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.enabled || changes.allowedSites || changes.customTerms) applySettings();
  });

  // The popup asks this page for its status
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "getStatus") {
      sendResponse({ host: HOST, count: blockedCount(), active: enabled });
    }
  });

  if (document.body) {
    applySettings();
  } else {
    document.addEventListener("DOMContentLoaded", applySettings, { once: true });
  }
})();
